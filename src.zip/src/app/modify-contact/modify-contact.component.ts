import { Component, OnInit } from '@angular/core';
import { contact } from '../contact';
import { contactservice } from '../contactservice';

@Component({
  selector: 'app-modify-contact',
  templateUrl: './modify-contact.component.html',
  styleUrls: ['./modify-contact.component.css']
})
export class ModifyContactComponent implements OnInit {
  con : contact = new contact();
  constructor(private service: contactservice) { }

  ngOnInit(): void {
  }
  updateContact() {
    //alert(JSON.stringify(this.carPart));
    this.service.updateContact(this.con).subscribe(data => {
     
     // alert(JSON.stringify(data));
    })
  }
}
