export class contact{
    
    contactName: String;
    contactNumber: String;
   
}
