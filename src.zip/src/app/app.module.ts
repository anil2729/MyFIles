import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddContactComponent } from './add-contact/add-contact.component';
import { ViewAllContactsComponent } from './view-all-contacts/view-all-contacts.component';
import { ViewContactComponent } from './view-contact/view-contact.component';
import { DeleteContactComponent } from './delete-contact/delete-contact.component';
import { ModifyContactComponent } from './modify-contact/modify-contact.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from'@angular/common/http';
import { contactservice } from './contactservice';
import { searchservice } from './searchservice';


@NgModule({
  declarations: [
    AppComponent,
    AddContactComponent,
    ViewAllContactsComponent,
    ViewContactComponent,
    DeleteContactComponent,
    ModifyContactComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
   
  ],
  providers: [contactservice,searchservice],
  bootstrap: [AppComponent]
})
export class AppModule { }
