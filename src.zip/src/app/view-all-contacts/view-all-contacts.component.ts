import { Component, OnInit } from '@angular/core';
import { contactservice } from '../contactservice';

@Component({
  selector: 'app-view-all-contacts',
  templateUrl: './view-all-contacts.component.html',
  styleUrls: ['./view-all-contacts.component.css']
})
export class ViewAllContactsComponent implements OnInit {

  contacts: any;

  constructor(private service: contactservice) { }

  viewAllContacts(){
    this.service.fetchAllContacts().subscribe(data =>{
      this.contacts=data;
    })
    
    }


  ngOnInit(): void {
  }

}
