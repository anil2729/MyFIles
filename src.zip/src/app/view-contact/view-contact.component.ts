import { Component, OnInit } from '@angular/core';
import { contact } from '../contact';
import { contactservice } from '../contactservice';
import { searchservice } from '../searchservice';

@Component({
  selector: 'app-view-contact',
  templateUrl: './view-contact.component.html',
  styleUrls: ['./view-contact.component.css']
})
export class ViewContactComponent implements OnInit {

  
  
  constructor(private service: searchservice) { }
  lstcontact: contact[];
  nametosearch: string;


  ngOnInit(): void {
    this.service.getcontact()
    .subscribe(
      data=>{
        this.lstcontact=data;
      }
    )
  }

}
