import { HttpClient } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { contact } from './contact';


@Injectable()
export class contactservice{
 
    constructor(private http: HttpClient) { }
    fetchAllContacts(){
        let url = 'http://localhost:8085/Phonebook/rest/Contacts';
        return this.http.get(url);

    }
       addContact(contact: contact){
        let url = 'http://localhost:8085/Phonebook/rest/Contacts/add';
        return this.http.post(url, contact);
        
      }
      updateContact(contact: contact){
        let url = 'http://localhost:8085/Phonebook/rest/Contacts/update';
        return this.http.put(url, contact);
    
      }
      deleteContact(contactName: string){
        let url = 'http://localhost:8085/Phonebook/rest/Contacts/';
        return this.http.delete(url+contactName);
      }
    
}