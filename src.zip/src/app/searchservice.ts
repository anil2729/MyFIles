import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { Observable } from 'rxjs';

@Injectable()
export class searchservice
{
   constructor(private httpclient: HttpClient){}

   getcontact(): Observable<any>
   {
      return this.httpclient.get("http://localhost:8085/Phonebook/rest/Contacts");
   }
  
   
}